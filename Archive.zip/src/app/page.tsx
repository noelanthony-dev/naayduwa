import MonthCalendar from "@/components/Calendar/MonthCalendar";
import AddEventModal from "@/components/modals/AddEventModal";
import ThemeToggle from "@/components/ThemeToggle";

export default function Page() {
  return (
    <main className="container py-10">
      <div className="mx-auto max-w-5xl space-y-6">
        <div className="flex items-center justify-between">
          <h1 className="text-3xl font-semibold">Naay Duwa? — Calendar</h1>
          <ThemeToggle />
        </div>

        <MonthCalendar />
        <AddEventModal />
      </div>
    </main>
  );
}