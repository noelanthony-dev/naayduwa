//# Central state (events, selectedDate, open modals)

"use client";

import React, { createContext, useContext, useMemo, useReducer } from "react";
import { CalendarState, EventItem } from "@/types/event";
import { load, save } from "@/lib/storage";
import { startOfMonthISO, toISODate } from "@/lib/date";

type Action =
  | { type: "NAV_MONTH"; payload: number } // +1 / -1
  | { type: "SET_SELECTED_DATE"; payload?: string }
  | { type: "OPEN_ADD_EVENT"; payload: string } // dateISO
  | { type: "CLOSE_ADD_EVENT" }
  | { type: "ADD_EVENT"; payload: EventItem };

const todayISO = toISODate(new Date());

const initialState: CalendarState = load<CalendarState>({
  monthCursorISO: startOfMonthISO(new Date()),
  selectedDateISO: todayISO,
  events: [],
  modal: { addEventOpen: false },
});

function reducer(state: CalendarState, action: Action): CalendarState {
  switch (action.type) {
    case "NAV_MONTH": {
      const d = new Date(state.monthCursorISO + "T00:00:00Z");
      d.setUTCMonth(d.getUTCMonth() + action.payload);
      const monthCursorISO = startOfMonthISO(d);
      const next = { ...state, monthCursorISO };
      save(next);
      return next;
    }
    case "SET_SELECTED_DATE": {
      const next = { ...state, selectedDateISO: action.payload };
      save(next);
      return next;
    }
    case "OPEN_ADD_EVENT": {
      const next = { ...state, modal: { ...state.modal, addEventOpen: true }, selectedDateISO: action.payload };
      save(next);
      return next;
    }
    case "CLOSE_ADD_EVENT": {
      const next = { ...state, modal: { ...state.modal, addEventOpen: false } };
      save(next);
      return next;
    }
    case "ADD_EVENT": {
      const events = [...state.events, action.payload].sort(
        (a, b) => a.dateISO.localeCompare(b.dateISO) || a.startTime.localeCompare(b.startTime)
      );
      const next = { ...state, events, modal: { ...state.modal, addEventOpen: false } };
      save(next);
      return next;
    }
    default:
      return state;
  }
}

const Ctx = createContext<{ state: CalendarState; dispatch: React.Dispatch<Action> } | null>(null);

export function CalendarProvider({ children }: { children: React.ReactNode }) {
  const [state, dispatch] = useReducer(reducer, initialState);
  const value = useMemo(() => ({ state, dispatch }), [state]);
  return React.createElement(Ctx.Provider, { value }, children);
}

export function useCalendar() {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("useCalendar must be used within CalendarProvider");
  return ctx;
}