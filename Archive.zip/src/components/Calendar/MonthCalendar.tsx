// High-level calendar grid (month view)

"use client";
import DayCell from "./DayCell";
import { useCalendar } from "@/store/useCalendarStore";

function getGrid(monthISO: string): { dateISO: string; isCurrentMonth: boolean }[] {
  const [y, m] = monthISO.split("-").map(Number);
  const first = new Date(Date.UTC(y, m - 1, 1));
  const startWeekday = (first.getUTCDay() + 6) % 7; // Mon=0
  const daysInCur = new Date(y, m, 0).getDate();

  // prev month spill
  const prevMonthDays: { dateISO: string; isCurrentMonth: boolean }[] = [];
  for (let i = startWeekday - 1; i >= 0; i--) {
    const d = new Date(Date.UTC(y, m - 1, -i));
    prevMonthDays.push({ dateISO: d.toISOString().slice(0, 10), isCurrentMonth: false });
  }

  // current
  const cur: { dateISO: string; isCurrentMonth: boolean }[] = [];
  for (let i = 1; i <= daysInCur; i++) {
    const d = new Date(Date.UTC(y, m - 1, i));
    cur.push({ dateISO: d.toISOString().slice(0, 10), isCurrentMonth: true });
  }

  // next spill to complete 42 cells (6 weeks)
  const total = prevMonthDays.length + cur.length;
  const remain = 42 - total;
  const next: { dateISO: string; isCurrentMonth: boolean }[] = [];
  for (let i = 1; i <= remain; i++) {
    const d = new Date(Date.UTC(y, m - 1, daysInCur + i));
    next.push({ dateISO: d.toISOString().slice(0, 10), isCurrentMonth: false });
  }

  return [...prevMonthDays, ...cur, ...next];
}

export default function MonthCalendar() {
  const { state, dispatch } = useCalendar();
  const grid = getGrid(state.monthCursorISO);

  const [year, month] = state.monthCursorISO.split("-");

  return (
    <div className="card">
      <div className="mb-4 flex items-center justify-between">
        <div className="text-lg font-semibold">{`${year}-${month}`}</div>
        <div className="flex gap-2">
          <button className="btn-ghost" onClick={() => dispatch({ type: "NAV_MONTH", payload: -1 })}>Prev</button>
          <button className="btn-ghost" onClick={() => dispatch({ type: "NAV_MONTH", payload: 1 })}>Next</button>
        </div>
      </div>

      <div className="grid grid-cols-7 gap-2">
        {["Mon","Tue","Wed","Thu","Fri","Sat","Sun"].map(d => (
          <div key={d} className="text-xs opacity-70">{d}</div>
        ))}
        {grid.map(cell => (
          <DayCell key={cell.dateISO} dateISO={cell.dateISO} isCurrentMonth={cell.isCurrentMonth} />
        ))}
      </div>
    </div>
  );
}