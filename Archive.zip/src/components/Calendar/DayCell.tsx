//Single day cell rendering

"use client";
import { useCalendar } from "@/store/useCalendarStore";

interface DayCellProps {
  dateISO: string;
  isCurrentMonth: boolean;
}

export default function DayCell({ dateISO, isCurrentMonth }: DayCellProps) {
  const { state, dispatch } = useCalendar();
  const events = state.events.filter(e => e.dateISO === dateISO);

  return (
    <button
      onClick={() => dispatch({ type: "OPEN_ADD_EVENT", payload: dateISO })}
      className={`h-24 w-full rounded-xl p-2 text-left border hover:border-primary/40 transition
        ${isCurrentMonth ? "border-white/10" : "border-white/5 opacity-50"}
      `}
      title="Click to add event"
    >
      <div className="text-xs mb-1 opacity-80">{dateISO.slice(-2)}</div>
      <div className="space-y-1">
        {events.slice(0, 2).map(ev => (
          <div key={ev.id} className="truncate rounded-md bg-white/10 px-2 py-1 text-xs">
            {ev.startTime} {ev.brand ? `• ${ev.brand}` : ""}
          </div>
        ))}
        {events.length > 2 && (
          <div className="text-[11px] opacity-60">+{events.length - 2} more</div>
        )}
      </div>
    </button>
  );
}