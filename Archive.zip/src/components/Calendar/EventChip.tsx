//Inline chip w/ logo + start time + attendees count
