//Add/remove attendees, prevent duplicates
