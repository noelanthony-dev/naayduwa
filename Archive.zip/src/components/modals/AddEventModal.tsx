//Create event (date, start/end, court, notes, logo)

"use client";
import { useState } from "react";
import Modal from "@/components/ui/Modal";
import { useCalendar } from "@/store/useCalendarStore";
import { EventItem } from "@/types/event";

export default function AddEventModal() {
  const { state, dispatch } = useCalendar();
  const open = state.modal.addEventOpen;
  const dateISO = state.selectedDateISO ?? new Date().toISOString().slice(0, 10);

  const [startTime, setStartTime] = useState("18:00");
  const [endTime, setEndTime] = useState("");
  const [court, setCourt] = useState("Pino");
  const [brand, setBrand] = useState("");
  const [notes, setNotes] = useState("");

  const onSave = () => {
    const ev: EventItem = {
      id: crypto.randomUUID(),
      dateISO,
      startTime,
      endTime: endTime || undefined,
      court,
      brand: brand || undefined,
      notes: notes || undefined,
      attendees: [],
      updatedAt: Date.now(),
    };
    dispatch({ type: "ADD_EVENT", payload: ev });
  };

  return (
    <Modal open={open} onClose={() => dispatch({ type: "CLOSE_ADD_EVENT" })}>
      <h3 className="text-lg font-semibold mb-4">Add Event</h3>

      <div className="space-y-3">
        <div>
          <div className="label">Date</div>
          <input className="input" type="date" value={dateISO} readOnly />
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <div className="label">Start</div>
            <input className="input" type="time" value={startTime} onChange={e => setStartTime(e.target.value)} />
          </div>
          <div>
            <div className="label">End (optional)</div>
            <input className="input" type="time" value={endTime} onChange={e => setEndTime(e.target.value)} />
          </div>
        </div>

        <div>
          <div className="label">Court</div>
          <input className="input" value={court} onChange={e => setCourt(e.target.value)} placeholder="Pino" />
        </div>

        <div>
          <div className="label">Brand / Logo key</div>
          <input className="input" value={brand} onChange={e => setBrand(e.target.value)} placeholder="magnum" />
        </div>

        <div>
          <div className="label">Notes</div>
          <input className="input" value={notes} onChange={e => setNotes(e.target.value)} placeholder="fee, etc." />
        </div>
      </div>

      <div className="mt-5 flex justify-end gap-2">
        <button className="btn-ghost" onClick={() => dispatch({ type: "CLOSE_ADD_EVENT" })}>Cancel</button>
        <button className="btn-primary" onClick={onSave}>Save</button>
      </div>
    </Modal>
  );
}